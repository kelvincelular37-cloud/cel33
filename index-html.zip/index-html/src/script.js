/* ══════════════════════════════════════
   MGrepair — script.js
══════════════════════════════════════ */

/* ─── 1. NAVBAR: scroll effect + active link ─── */
const navbar = document.getElementById('navbar');
const navLinks = document.querySelectorAll('.nav-links a:not(.nav-cta)');
const sections = document.querySelectorAll('section[id]');

window.addEventListener('scroll', () => {
  // Sticky style
  if (window.scrollY > 40) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }

  // Active nav link
  let current = '';
  sections.forEach(section => {
    const top = section.offsetTop - 100;
    if (window.scrollY >= top) current = section.getAttribute('id');
  });
  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === `#${current}`) link.classList.add('active');
  });
}, { passive: true });

/* ─── 2. HAMBURGER MENU ─── */
const hamburger = document.getElementById('hamburger');
const navList   = document.getElementById('nav-links');

hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('open');
  navList.classList.toggle('open');
  document.body.style.overflow = navList.classList.contains('open') ? 'hidden' : '';
});

// Close on link click
navList.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('open');
    navList.classList.remove('open');
    document.body.style.overflow = '';
  });
});

// Close on outside click
document.addEventListener('click', (e) => {
  if (!navbar.contains(e.target)) {
    hamburger.classList.remove('open');
    navList.classList.remove('open');
    document.body.style.overflow = '';
  }
});

/* ─── 3. FLOATING PARTICLES ─── */
function createParticles() {
  const container = document.getElementById('particles');
  if (!container) return;

  const count = window.innerWidth < 768 ? 20 : 40;
  for (let i = 0; i < count; i++) {
    const p = document.createElement('div');
    p.classList.add('particle');

    const size   = Math.random() * 3 + 1;
    const left   = Math.random() * 100;
    const delay  = Math.random() * 15;
    const dur    = 12 + Math.random() * 18;

    p.style.cssText = `
      width: ${size}px;
      height: ${size}px;
      left: ${left}%;
      animation-duration: ${dur}s;
      animation-delay: ${delay}s;
      opacity: 0;
    `;
    container.appendChild(p);
  }
}
createParticles();

/* ─── 4. COUNTER ANIMATION ─── */
function animateCounter(el, target, suffix = '') {
  const duration = 2000;
  const startTime = performance.now();
  const startVal  = 0;

  function update(now) {
    const elapsed  = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased    = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    const value    = Math.round(startVal + (target - startVal) * eased);
    el.textContent = value.toLocaleString('es-CL');
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

// Trigger counters when hero is in view
const statNums = document.querySelectorAll('.stat-num');
let countersTriggered = false;

const heroObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting && !countersTriggered) {
      countersTriggered = true;
      statNums.forEach(el => {
        const target = parseInt(el.dataset.target, 10);
        animateCounter(el, target);
      });
    }
  });
}, { threshold: 0.3 });

const heroSection = document.getElementById('hero');
if (heroSection) heroObserver.observe(heroSection);

/* ─── 5. SCROLL-REVEAL (Intersection Observer) ─── */
const revealEls = document.querySelectorAll('.service-card, .store-card');

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el    = entry.target;
      const delay = parseInt(el.dataset.delay || 0, 10);
      setTimeout(() => el.classList.add('visible'), delay);
      revealObserver.unobserve(el);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

revealEls.forEach(el => revealObserver.observe(el));

/* ─── 6. CONTACT FORM ─── */
const form       = document.getElementById('contact-form');
const btnText    = document.getElementById('btn-text');
const btnLoader  = document.getElementById('btn-loader');
const formSuccess = document.getElementById('form-success');

if (form) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Simple client-side validation
    const fields = form.querySelectorAll('[required]');
    let valid = true;
    fields.forEach(f => {
      f.style.borderColor = '';
      if (!f.value.trim()) {
        f.style.borderColor = '#ff4d6d';
        valid = false;
      }
    });
    if (!valid) {
      shakeForm();
      return;
    }

    // Simulate async send
    btnText.style.display  = 'none';
    btnLoader.style.display = 'inline';

    await new Promise(r => setTimeout(r, 1600));

    btnText.style.display  = 'inline';
    btnLoader.style.display = 'none';
    form.reset();
    formSuccess.style.display = 'block';

    setTimeout(() => {
      formSuccess.style.display = 'none';
    }, 5000);
  });

  // Live validation feedback
  form.querySelectorAll('input, select, textarea').forEach(el => {
    el.addEventListener('input', () => {
      if (el.value.trim()) el.style.borderColor = '';
    });
  });
}

function shakeForm() {
  form.style.animation = 'shake 0.4s ease';
  form.addEventListener('animationend', () => {
    form.style.animation = '';
  }, { once: true });
}

// Inject shake animation
const shakeCSS = document.createElement('style');
shakeCSS.textContent = `
  @keyframes shake {
    0%,100% { transform: translateX(0); }
    20%     { transform: translateX(-8px); }
    40%     { transform: translateX(8px); }
    60%     { transform: translateX(-5px); }
    80%     { transform: translateX(5px); }
  }
`;
document.head.appendChild(shakeCSS);

/* ─── 7. ACTIVE NAV HIGHLIGHT STYLE ─── */
const activeStyle = document.createElement('style');
activeStyle.textContent = `.nav-links a.active { color: var(--cyan) !important; }`;
document.head.appendChild(activeStyle);

/* ─── 8. SMOOTH HOVER TILT on service cards ─── */
document.querySelectorAll('.service-card').forEach(card => {
  card.addEventListener('mousemove', (e) => {
    const rect   = card.getBoundingClientRect();
    const cx     = rect.left + rect.width / 2;
    const cy     = rect.top  + rect.height / 2;
    const dx     = (e.clientX - cx) / (rect.width / 2);
    const dy     = (e.clientY - cy) / (rect.height / 2);
    const rotX   = -dy * 5;
    const rotY   =  dx * 5;
    card.style.transform = `translateY(-6px) rotateX(${rotX}deg) rotateY(${rotY}deg)`;
  });
  card.addEventListener('mouseleave', () => {
    card.style.transform = '';
  });
});

/* ─── 9. WHATSAPP BUTTON: show after scroll ─── */
const waBtn = document.getElementById('whatsapp-btn');
if (waBtn) {
  waBtn.style.opacity = '0';
  waBtn.style.transform = 'scale(0.7)';
  waBtn.style.transition = 'opacity 0.4s ease, transform 0.4s ease, box-shadow 0.3s ease';

  setTimeout(() => {
    waBtn.style.opacity = '1';
    waBtn.style.transform = 'scale(1)';
  }, 1500);
}

/* ─── 10. SECTION FADE-IN on scroll ─── */
const sectionHeaders = document.querySelectorAll('.section-header, .trade-text, .contact-info');
const headerObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.animation = 'fadeInUp 0.7s ease both';
      headerObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

sectionHeaders.forEach(el => {
  el.style.opacity = '0';
  headerObserver.observe(el);
});

/* ─── 11. HERO CTA micro-interaction ─── */
document.querySelectorAll('.btn-primary').forEach(btn => {
  btn.addEventListener('mousedown', () => {
    btn.style.transform = 'scale(0.97)';
  });
  btn.addEventListener('mouseup', () => {
    btn.style.transform = '';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.transform = '';
  });
});

/* ─── 12. Store card: prevent tilt on mobile ─── */
if (window.matchMedia('(hover: hover)').matches) {
  document.querySelectorAll('.store-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const dx   = (e.clientX - rect.left - rect.width / 2) / (rect.width / 2);
      const dy   = (e.clientY - rect.top  - rect.height / 2) / (rect.height / 2);
      card.style.transform = `translateY(-5px) rotateX(${-dy * 4}deg) rotateY(${dx * 4}deg)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });
}

console.log('%cMGrepair 🔧', 'color:#00e5ff;font-size:1.5rem;font-weight:900;');
console.log('%cServicio técnico profesional — mgrepair.cl', 'color:#8bafd4;');
